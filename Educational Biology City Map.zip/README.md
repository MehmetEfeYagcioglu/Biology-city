
  # Educational Biology City Map

  This is a code bundle for Educational Biology City Map. The original project is available at https://www.figma.com/design/KgQOOe8fIuI1ALjQU09sGE/Educational-Biology-City-Map.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  